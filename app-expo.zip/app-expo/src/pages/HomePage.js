import React from 'react';
import {View, Text} from 'react-native';

const HomePage = () => {

return (

  <View> 
  
    <Text> Puc Minas </Text>

  </View>

);

}

export default HomePage;